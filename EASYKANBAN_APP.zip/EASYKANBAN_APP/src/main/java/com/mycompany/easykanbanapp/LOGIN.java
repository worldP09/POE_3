
package com.mycompany.easykanbanapp;



import javax.swing.JOptionPane;


public class LOGIN {
       
	private String name;
	private String surname;
	private String username;
	private String password;
	private String ConfirmU;
	private String ConfirmP;
        private final String lowerCaseChar = "(.*[a-z].*)";
	private final String upperCaseChars = "(.*[A-Z].*)";
	private final String number = "(.*[0-9].*)";
	private final String specialChars = "(.*[@,#,$,%,_].*$)";
	private final String specialChars2 = "_";
        
        
	
	//Constructor:prompt user to register FirstName and LastName 
	public String name() {

        name = JOptionPane.showInputDialog(null,"FirtName: ", "Registering", JOptionPane.PLAIN_MESSAGE);
		return name;
	}
        public String lastName(){
        surname = JOptionPane.showInputDialog(null,"LastName: ", "Registering", JOptionPane.PLAIN_MESSAGE);

            return surname;
        }

	//Loop:prompt user to register userName. 
	public boolean  user() {

	boolean validUsername = false;


	while(!validUsername) {

	this.username = JOptionPane.showInputDialog(null,"UserName: ", "Registering", JOptionPane.PLAIN_MESSAGE);

	if (this.username.length() > 0 && this.username.length()<=5 && this.username.contains(specialChars2 ) ) {
        JOptionPane.showMessageDialog(null, "username successfully captured", "successfully", JOptionPane.PLAIN_MESSAGE);

	validUsername = true;
        return true;
	}		
        else {
	JOptionPane.showMessageDialog(null, "username is not correctly formatted", "error 401", JOptionPane.PLAIN_MESSAGE);
	validUsername = false;       
		}
            }
	return false;
	}
	//Loop:prompt user to register password.
	public boolean  pass() {

        boolean validPassword = false;


	while (!validPassword ) {
			
	password = JOptionPane.showInputDialog(null,"Password: ", "Registering", JOptionPane.PLAIN_MESSAGE);

	if (password.length() < 20 && password.length() >= 8 && password.matches(upperCaseChars )&& password.matches(number )&& password.matches(specialChars)){
            JOptionPane.showMessageDialog(null,"Password successfully captured", "SUCCESSFUL", JOptionPane.PLAIN_MESSAGE);
            JOptionPane.showMessageDialog(null,"registering successful", "SUCCESSFUL", JOptionPane.PLAIN_MESSAGE);

        validPassword = true;
            return true;
	}else { 
            
	validPassword = false;
		}
	}
	return false;
           
	}
//boolean: check userName 
public boolean checkUserName() {
      
    this.ConfirmU = JOptionPane.showInputDialog(null,"Username: ", "Login", JOptionPane.PLAIN_MESSAGE);
                
    if(this.ConfirmU.length() > 0 && this.ConfirmU.length() <=5 && this.ConfirmU.matches(specialChars)) {
			
	return true;	
	}
	else {
        
	return false;
	}
}
        
//boolean : checking user password complexity
public boolean checkPasswordComplexity() {
    
    this.ConfirmP = JOptionPane.showInputDialog(null,"Password: ", "LOGIN", JOptionPane.PLAIN_MESSAGE);
		
    if(this.ConfirmP.length() <= 20 && this.ConfirmP.length() >= 8 && this.ConfirmP.matches(lowerCaseChar)&& this.ConfirmP.matches(upperCaseChars)&& this.ConfirmP.matches(number) && this.ConfirmP.matches(specialChars)) {

        return true;	
    }
    else {
	return false;
    }
}
	
	//string : checking user input 
public String registerUser(String ConfirmU ,String ConfirmP) {

               
    if (!checkUserName()) {
        JOptionPane.showMessageDialog(null, "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.", "error 401", JOptionPane.PLAIN_MESSAGE);
}
    if (!checkPasswordComplexity()) {
	JOptionPane.showMessageDialog(null, "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.", "error 401", JOptionPane.PLAIN_MESSAGE);	
}
	return ConfirmU+ConfirmP;
	}
//boolean: checking user logins 
public boolean loginUser(String confirmP, String confirmU) {

		if (this.ConfirmU.equals(username) && this.ConfirmP.equals(this.password)) {

			return true; 
		}else {

			return false;
		}

	}
//String :returning user login status
public String returnLoginStatus() {

    if(loginUser(ConfirmP ,ConfirmU)) {

	JOptionPane.showMessageDialog(null, "Login Successfully.", "EasyKanban App", JOptionPane.PLAIN_MESSAGE);
	JOptionPane.showMessageDialog(null, "Welcome "+name+" "+surname+" , it is great to see you again.", "SUCCESSFUL", JOptionPane.PLAIN_MESSAGE);
        
			return ConfirmU + ConfirmP;
		}
		else {
			JOptionPane.showMessageDialog(null, "login failed try again", "error 401", JOptionPane.PLAIN_MESSAGE);
                        System.exit(0);
			return ConfirmU + ConfirmP;
		}
	}  
}