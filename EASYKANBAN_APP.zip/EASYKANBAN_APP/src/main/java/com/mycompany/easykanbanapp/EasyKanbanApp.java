package com.mycompany.easykanbanapp;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;

public class EasyKanbanApp {
    
    public static int taskCount = 0;
    public static String WELCOME_MESSAGE = "Welcome to EasyKanban";
    public static List<Task> tasks = new ArrayList<>();
    public static List<String> developers = new ArrayList<>();
    public static List<String> taskNames = new ArrayList<>();
    public static List<String> taskIDs = new ArrayList<>();
    public static List<Integer> taskDurations = new ArrayList<>();
    public static List<String> taskStatuses = new ArrayList<>();

    public static void main(String[] args) {
        
        JOptionPane.showMessageDialog(null, WELCOME_MESSAGE);
        boolean loggedIn = false;
        while (!loggedIn) {
            loggedIn = performLogin();
        }
        int choice = 0;
        while (choice != 8) {
            choice = displayMenu();
            switch (choice) {
                case 1:
                    addTask();
                    Task.displayReport();
                    break;
                case 2:
                    Task.displayReport();
                    break;
                case 3:
                    Task.displayTasksWithStatusDone();
                    break;
                case 4:
                    Task.displayLongestTaskDuration();
                    break;
                case 5:
                    String taskName = JOptionPane.showInputDialog(null, "Enter the task name to search:");
                    Task.searchTaskByName(taskName);
                    break;
                case 6:
                    Task.searchTasksByDeveloper();
                    break;
                case 7:
                    Task.deleteTaskByName();
                    break;
                case 8:
                    JOptionPane.showMessageDialog(null, "Quitting the application...");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice! Please try again.");
                    break;
            }
        }
    }

    public static boolean performLogin() {
       
        
        LOGIN check2 = new LOGIN();
        check2.name();
        check2.lastName();
        check2.user();
        check2.pass();
        check2.registerUser("","");
        check2.loginUser("","");
        check2.returnLoginStatus();
        return true;
    }

    public static int displayMenu() {
        String menu = "Please choose an option:\n" +
                "1) Add tasks\n" +
                "2) Show report\n" +
                "3) 'Done' task status\n" +
                "4) Longest task\n" +
                "5) Search for a task by name\n" +
                "6) Search for tasks assigned to a developer\n" +
                "7) Delete a task by name\n" +
                "8) Quit";

        int choice = 0;
        boolean validChoice = false;
        while (!validChoice) {
            try {
                String choiceStr = JOptionPane.showInputDialog(null, menu);
                choice = Integer.parseInt(choiceStr);
                validChoice = true;
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid choice! Please enter a number.");
            }
        }
        return choice;
    }

    public static String  addTask() {
        String taskName = null;
      
        int numberOfTasks = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the number of tasks:"));
        for (int i = 0; i < numberOfTasks; i++) {
            Task task = new Task();
            task.setTaskNumber(taskCount);
            taskCount++;

            taskName = JOptionPane.showInputDialog(null, "Enter the task name:");
            
            task.setTaskName(taskName);

            String taskDescription = JOptionPane.showInputDialog(null, "Enter the task description:");
            boolean validDescription = task.checkTaskDescription(taskDescription);
            while (!validDescription) {
                taskDescription = JOptionPane.showInputDialog(null, "Please enter a task description of less than 50 characters:");
                validDescription = task.checkTaskDescription(taskDescription);
            }
            task.setTaskDescription(taskDescription);

            String firstName = JOptionPane.showInputDialog(null, "Enter the developer's first name:");
            String lastName = JOptionPane.showInputDialog(null, "Enter the developer's last name:");
            task.setDeveloperDetails(firstName, lastName);

            int taskDuration = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the task duration (in hours):"));
            task.setTaskDuration(taskDuration);

            // Task Status Menu
            String[] statusOptions = {"To Do", "Done", "Doing"};
            int statusChoice = JOptionPane.showOptionDialog(null, "Select the task status:", "Task Status", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, statusOptions, statusOptions[0]);
            String taskStatus = statusOptions[statusChoice];
            task.setTaskStatus(taskStatus);

            task.generateTaskID();

            tasks.add(task);
            developers.add(firstName + " " + lastName);
            taskNames.add(taskName);
            taskIDs.add(task.getTaskID());
            taskDurations.add(taskDuration);

            JOptionPane.showMessageDialog(null, "Task successfully captured");
        }
        return taskName;
    }
    
   
}
