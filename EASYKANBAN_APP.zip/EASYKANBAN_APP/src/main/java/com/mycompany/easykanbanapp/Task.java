
package com.mycompany.easykanbanapp;

import static com.mycompany.easykanbanapp.EasyKanbanApp.tasks;
import javax.swing.JOptionPane;

 public class Task {
        
        public String taskName;
        private int taskNumber;
        private String taskDescription;
        private String developerFirstName;
        private String developerLastName;
        private int taskDuration;
        private String taskID;
        private String taskStatus;

        public void  setTaskName(String taskName) {
            this.taskName = taskName;
        }

        public void setTaskDescription(String taskDescription) {
            this.taskDescription = taskDescription;
        }

        public boolean checkTaskDescription(String taskDescription) {
            return taskDescription.length() <= 50;
        }

        public void setDeveloperDetails(String firstName, String lastName) {
        if (firstName != null && !firstName.isEmpty()) {
        this.developerFirstName = firstName;
        } else {
        this.developerFirstName = "";
        }

        if (lastName != null && !lastName.isEmpty()) {
        this.developerLastName = lastName;
        } else {
        this.developerLastName = "";
    }
}
        public void setTaskDuration(int taskDuration) {
            this.taskDuration = taskDuration;
        }
        
        public void setTaskNumber(int taskNumber) {
            this.taskNumber = taskNumber;
        }

        public void generateTaskID() {
        String taskNameAbbreviation = taskName.substring(0, 2).toUpperCase();
        String developerNameAbbreviation = developerLastName.substring(developerLastName.length() - 3).toUpperCase();
        this.taskID = taskNameAbbreviation + ":" + taskNumber + ":" + developerNameAbbreviation;
        }

        public void setTaskStatus(String taskStatus) {
            this.taskStatus = taskStatus;
        }

        public String getTaskStatus() {
            return taskStatus;
        }

        public String getDeveloperDetails() {
            return developerFirstName + " " + developerLastName;
        }

        public int getTaskNumber() {
            return taskNumber;
        }

        public String getTaskName() {
            return taskName;
        }

        public String getTaskDescription() {
            return taskDescription;
        }

        public String getTaskID() {
            return taskID;
        }

        public int getTaskDuration() {
            return taskDuration;
        }
        public static String  displayReport() {
        StringBuilder report = new StringBuilder("Task Report:\n\n");
        int totalHours = 0;

        for (Task task : EasyKanbanApp.tasks) {
            report.append("Task Status: ").append(task.getTaskStatus()).append("\n");
            report.append("Developer Details: ").append(task.getDeveloperDetails()).append("\n");
            report.append("Task Number: ").append(task.getTaskNumber()).append("\n");
            report.append("Task Name: ").append(task.getTaskName()).append("\n");
            report.append("Task Description: ").append(task.getTaskDescription()).append("\n");
            report.append("Task ID: ").append(task.getTaskID()).append("\n");
            report.append("Task Duration: ").append(task.getTaskDuration()).append(" hours\n\n");

            totalHours += task.getTaskDuration();
        }

        report.append("Total Hours: ").append(totalHours);

        JOptionPane.showMessageDialog(null, report.toString());
        return "true";
    }

    public static String  displayTasksWithStatusDone() {
        StringBuilder report = new StringBuilder("Tasks with Status 'Done':\n\n");

        for (Task task : EasyKanbanApp.tasks) {
            if (task.getTaskStatus().equalsIgnoreCase("Done")) {
                report.append("Task Name: ").append(task.getTaskName()).append("\n");
                report.append("Developer: ").append(task.getDeveloperDetails()).append("\n");
                report.append("Task Duration: ").append(task.getTaskDuration()).append(" hours\n\n");
            }
            
        }

        if (report.length() == 0) {
            report.append("No tasks with status 'Done' found.\n");
        }

        JOptionPane.showMessageDialog(null, report.toString());
        return "true";
    }
        public static String  displayLongestTaskDuration() {
        if (EasyKanbanApp.tasks.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No tasks found.");
            return "false";
        }

        int longestDuration = 0;
        Task longestTask = null;

        for (Task task : EasyKanbanApp.tasks) {
            if (task.getTaskDuration() > longestDuration) {
                longestDuration = task.getTaskDuration();
                longestTask = task;
            }
        }

        if (longestTask != null) {
            StringBuilder report = new StringBuilder("Task with Longest Duration:\n\n");
            report.append("Task Name: ").append(longestTask.getTaskName()).append("\n");
            report.append("Developer: ").append(longestTask.getDeveloperDetails()).append("\n");
            report.append("Task Duration: ").append(longestTask.getTaskDuration()).append(" hours\n");

            JOptionPane.showMessageDialog(null, report.toString());
            return "true";
            
        } else {
            JOptionPane.showMessageDialog(null, "No tasks found.");
            
            return "false";
        }
      
    }

        public static String  searchTaskByName(String taskName) {
        boolean found = false;
        StringBuilder report = new StringBuilder("Search Results:\n\n");

        for (Task task : EasyKanbanApp.tasks) {
            if (task.getTaskName().equalsIgnoreCase(taskName)) {
                report.append("Task Name: ").append(task.getTaskName()).append("\n");
                report.append("Developer: ").append(task.getDeveloperDetails()).append("\n");
                report.append("Task Status: ").append(task.getTaskStatus()).append("\n\n");
                found = true;
            }
        }

        if (found) {
            JOptionPane.showMessageDialog(null, report.toString());
            return "true";
        } else {
            JOptionPane.showMessageDialog(null, "No tasks found with the specified name.");
            return "false";
        }
    }

public static String  searchTasksByDeveloper() {
    String searchDeveloper = JOptionPane.showInputDialog(null, "Enter the developer's name to search:");

    StringBuilder report = new StringBuilder("Tasks Assigned to Developer: " + searchDeveloper + "\n\n");

    boolean found = false;
    for (int i = 0; i < EasyKanbanApp.tasks.size(); i++) {
        Task task = EasyKanbanApp.tasks.get(i);
        if (task.getDeveloperDetails().equalsIgnoreCase(searchDeveloper)) {
            report.append("Task Name: ").append(task.getTaskName()).append("\n");
            report.append("Task Status: ").append(task.getTaskStatus()).append("\n\n");
            found = true;
        }
    }

    if (found) {
        JOptionPane.showMessageDialog(null, report.toString());
        return "true";
    } else {
        JOptionPane.showMessageDialog(null, "No tasks found for the specified developer.");
        return "false";
    }
}
    public static String  deleteTaskByName() {
    String deleteName = JOptionPane.showInputDialog(null, "Enter the task name to delete:");

    int index = -1;
    for (int i = 0; i < EasyKanbanApp.taskNames.size(); i++) {
        if (EasyKanbanApp.taskNames.get(i).equals(deleteName)) {
            index = i;
            break;
        }
    }

    if (index != -1) {
        if (index < EasyKanbanApp.tasks.size()) {
            EasyKanbanApp.tasks.remove(index);
        }
        if (index < EasyKanbanApp.developers.size()) {
            EasyKanbanApp.developers.remove(index);
        }
        if (index < EasyKanbanApp.taskNames.size()) {
            EasyKanbanApp.taskNames.remove(index);
        }
        if (index < EasyKanbanApp.taskIDs.size()) {
            EasyKanbanApp.taskIDs.remove(index);
        }
        if (index < EasyKanbanApp.taskDurations.size()) {
            EasyKanbanApp.taskDurations.remove(index);
        }
        if (index < EasyKanbanApp.taskStatuses.size()) {
            EasyKanbanApp.taskStatuses.remove(index);
        }
        JOptionPane.showMessageDialog(null, "Task deleted successfully!");
        return "true";
    } else {
        JOptionPane.showMessageDialog(null, "Task not found!");
        return "false";
    }
}

    }

    

