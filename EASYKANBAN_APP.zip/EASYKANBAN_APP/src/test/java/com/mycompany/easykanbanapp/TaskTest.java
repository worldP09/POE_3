/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.easykanbanapp;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testCheckTaskDescription() {
        // Test case 1: Valid description
        String taskDescription = "Create Login to authenticate users";
        Task task = new Task();
        boolean validDescription = task.checkTaskDescription(taskDescription);
        Assertions.assertTrue(validDescription);

        // Test case 2: Description exceeds the limit
        taskDescription = "This is a long description that exceeds the maximum allowed characters limit of 50";
        validDescription = task.checkTaskDescription(taskDescription);
        Assertions.assertFalse(validDescription);
    }

    @Test
    public void testGenerateTaskID() {
        // Test case 1
        Task task = new Task();
        task.setTaskName("Login Feature");
        task.setTaskNumber(1);
        task.setDeveloperDetails("Robyn", "Harrison");
        task.generateTaskID();
        Assertions.assertEquals("LO:0:HAR", task.getTaskID());

        // Test case 2
        task.setTaskName("Login Feature");
        task.setTaskNumber(2);
        task.setDeveloperDetails("Mike", "Smith");
        task.generateTaskID();
        Assertions.assertEquals("AD:2:SMI", task.getTaskID());
    }

    @Test
    public void testGetDeveloperDetails() {
        Task task = new Task();
        task.setDeveloperDetails("John", "Doe");
        Assertions.assertEquals("John Doe", task.getDeveloperDetails());
    }

    @Test
    public void testGettersAndSetters() {
        Task task = new Task();

        // Set values
        task.setTaskName("Task 1");
        task.setTaskNumber(1);
        task.setTaskDescription("Description");
        task.setDeveloperDetails("John", "Doe");
        task.setTaskDuration(10);
        task.setTaskStatus("Doing");

        // Verify values using getters
        Assertions.assertEquals("Task 1", task.getTaskName());
        Assertions.assertEquals(1, task.getTaskNumber());
        Assertions.assertEquals("Description", task.getTaskDescription());
        Assertions.assertEquals("John Doe", task.getDeveloperDetails());
        Assertions.assertEquals(10, task.getTaskDuration());
        Assertions.assertEquals("Doing", task.getTaskStatus());
    }
}

