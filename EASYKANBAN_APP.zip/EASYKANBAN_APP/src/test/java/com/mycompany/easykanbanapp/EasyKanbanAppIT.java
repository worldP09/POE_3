package com.mycompany.easykanbanapp;

import javax.swing.JOptionPane;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class EasyKanbanAppIT {

    public EasyKanbanAppIT() {
        
    }

    

    @Test
    public void testMain() {
        
       EasyKanbanApp app = new EasyKanbanApp();
       Task well =  new Task();
       JOptionPane.showMessageDialog(null, "test for the taken name:");
       String now = app.addTask();
       well.setTaskName(now);
       String power = well.taskName;
       assertEquals(now,power);
       JOptionPane.showMessageDialog(null,now == power);
       
       JOptionPane.showMessageDialog(null, "test the display method:");
       String zoe = well.displayReport();
       String uzi ="true"; 
       assertEquals(zoe,uzi);
       JOptionPane.showMessageDialog(null,zoe == uzi);
       
       
       JOptionPane.showMessageDialog(null, "test the done status:");
       String weak = well.displayTasksWithStatusDone();
       String strong ="true";
       assertEquals(weak ,strong);
       JOptionPane.showMessageDialog(null,weak == strong);
       
       
       JOptionPane.showMessageDialog(null, "test search:");
       String point  = well.searchTaskByName("");
       String up = "true";
       assertEquals(point ,up);
       JOptionPane.showMessageDialog(null,point == up);
       
       
       JOptionPane.showMessageDialog(null,"test search by devName");
       String sore =  well.searchTasksByDeveloper();
       String heal = power;
       assertEquals(sore , heal );
       JOptionPane.showMessageDialog(null,sore == heal);
 
       JOptionPane.showMessageDialog(null,"test delete feature");
       String low = well.deleteTaskByName();
       String pass = "true";
       assertEquals(low,pass);
       JOptionPane.showMessageDialog(null,low == pass);
    }
}